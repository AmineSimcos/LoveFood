package dz.baichoudjedi.lovefood.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import dz.baichoudjedi.lovefood.R;

public class fragmentAccueil  extends Fragment {
    public static TextView txt;
    private FloatingActionButton btn;
    private VideoView v_background;
    private String path = "android.resource://dz.baichoudjedi.lovefood/" + R.raw.video2;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_accueil,container,false);
        btn = v.findViewById(R.id.floating3);
        v_background = v.findViewById(R.id.vv_background);
        //Uri u = Uri.parse(path);
        //v_background.setVideoURI(u);
        //v_background.start();
        /*v_background.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setLooping(true);
            }
        });*/
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(getActivity(), ScanCodeActivity.class);
                    //Intent intent = new Intent(getActivity(), ListeProduitsActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivity(intent);
                }
                else {
                    ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA}, 0);
                }
            }
        });
        return v;
    }

    @Override
    public void onResume() {
//        v_background.resume();
        super.onResume();
    }

    @Override
    public void onPause() {
//        v_background.suspend();
        super.onPause();
    }

    @Override
    public void onDestroy() {
//        v_background.stopPlayback();
        super.onDestroy();
    }
}
