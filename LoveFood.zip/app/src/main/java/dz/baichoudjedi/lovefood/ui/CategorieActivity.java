package dz.baichoudjedi.lovefood.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.view.MenuItemCompat;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.GridView;

import java.util.ArrayList;

import dz.baichoudjedi.lovefood.model.Categorie;
import dz.baichoudjedi.lovefood.R;
import dz.baichoudjedi.lovefood.model.Produit;
import dz.baichoudjedi.lovefood.myadapter.GridViewAdapter;

public class CategorieActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categorie);

//        ArrayList<Produit> liste_categorie = new ArrayList<>();
//        liste_categorie.add(new Categorie("Fromage", R.drawable.fromages));
//        liste_categorie.add(new Categorie("Cachir", R.drawable.cachir));
//        liste_categorie.add(new Categorie("Boisson", R.drawable.boissons));
//        liste_categorie.add(new Categorie("Glaces", R.drawable.glaces));
//        liste_categorie.add(new Categorie("Lait", R.drawable.lait));
//        liste_categorie.add(new Categorie("Eau", R.drawable.eau));
//        liste_categorie.add(new Categorie("Cupcake", R.drawable.cupkake));
//        liste_categorie.add(new Categorie("Miel", R.drawable.miels));
//        liste_categorie.add(new Categorie("Cookies", R.drawable.cookies));
//
//        GridViewAdapter adapter = new GridViewAdapter(this, liste_categorie);
//        GridView gv = findViewById(R.id.gv_liste);
//        gv.setAdapter(adapter);
    }

}
